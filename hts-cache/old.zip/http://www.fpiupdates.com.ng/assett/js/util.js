<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:url" content="https://fpiupdates.com.ng">
    <meta property="og:type" content="article">
    <meta property="og:author" content="Odewaye Mayomi Peter">

    
    <meta property="og:title" content="Welcome to FPI Updates Platform">
    <meta property="og:url" content="https://fpiupdates.com.ng">
    <meta property="og:description" content="FPI Updates is a platform developed for students in Federal Polytechnic Ilaro to get more updates, past questions also serves as the voice of students and also to help them in their studies and their side hustles or businesses.">
    
    <meta property="og:image" content="https://fpiupdates.com.ng/media/featuredImage/FPI%20OLEVEL%20Combinations.jpg">
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 
    <link rel="icon" type="image/PNG" href="/assets/img/favicon.png"/>
    <link rel="stylesheet" href="/../../assets/css/success.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/fontawesome.min.css">
	<link rel="stylesheet" href="/assets/css/videostyle.css" />
	
	
	<meta name="google-site-verification" content="CrlInUNwq6z9JAw17w_7GkP1xzWPP8b2Y5jbXFqPIUI" />
	
	<!--Google Ads Monetization Section-->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7448090304026142"
     crossorigin="anonymous"></script>

<!--Social Share buttons JavaScript activation code-->
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=6409b4abe1ac6c001a8a8501&product=inline-share-buttons' async='async'></script>
<style>
    p{
        font-size: 19px;
        font-weight: 300;
    }
        /* ====Paragraph==== */
@media screen and (max-width: 900px){
    p,li,ul,ol{
        /* margin-left: 20px; */
        font-size: 17px;
        font-weight: normal;
    }

    ul,ol{
        margin-left: 20px;
        /*padding-left: 10px;*/
    }
    }
</style>
</head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-87HSBZ3PEJ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-87HSBZ3PEJ');
</script><title>404 Page Not Found | FPI Updates</title>  
<body>
    <div class="main">
        <main>
            <section class="ponstHero">
            <h1 class="fs-900 text- fw-bold mt-2" style="text-align: center;">404</h1>

                <!-- <div class="hero-bg-overlay">
                    <div class="container">
                        <div class="heroContent">
                            <div class="heroHT">
                                <h1 class="fs-800 text-light fw-bold">404</h1>
                            </div>
                        </div>
                    </div>
                </div> -->
            </section>



        <div class="container">

          

        <section class="posts">
            
            <div class="fs-600 j-center subheading" style="text-align: center;">
                <h2 class="fw-bold j-center mtb-2">Oopps!!! Page Not Found</h2>
            </div>
            
        
        

            <hr class="text-orange">

            <div class="postSection mtb-2">
                
               
                    <div class="postCard mb-2 d-flex j-sb" >
                    <div class='fw-bold d-flex a-center fs-800 subheading' style='color:red'b  >It seems you are in wrong Direction</div>
                    
                    </div>
   
            </div>
            <a href="/index"><button class="btn"><i class="fas fa-arrow-left"></i> Navigate Back Home</button></a>'; 



            
        </section>


    </div>
    </section>

            
        </main>        

    </div>



</body>
</html>